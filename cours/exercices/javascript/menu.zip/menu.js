document.querySelector('.toggle-menu').addEventListener('click', function() {
  document.querySelector('.menu').classList.toggle('ferme');
});

document.querySelector('.fermer-menu').addEventListener('click', function() {
  document.querySelector('.menu').classList.toggle('ferme');
});
